def apply_stop_loss_take_profit(api, symbol, position_qty, stop_loss_pct=0.05, take_profit_pct=0.1):
    try:
        position = api.get_position(symbol)
        stop_price = float(position.avg_entry_price) * (1 - stop_loss_pct)
        take_profit_price = float(position.avg_entry_price) * (1 + take_profit_pct)
        
        stop_loss_order = api.submit_order(
            symbol=symbol,
            qty=position_qty,
            side='sell',
            type='stop',
            stop_price=stop_price,
            time_in_force='gtc'
        )
        
        take_profit_order = api.submit_order(
            symbol=symbol,
            qty=position_qty,
            side='sell',
            type='limit',
            limit_price=take_profit_price,
            time_in_force='gtc'
        )
        
        print(f"Stop loss set at: {stop_price}, Take profit set at: {take_profit_price}")
    except Exception as e:
        print(f"Error in risk management for {symbol}: {e}")