from alpaca_trade_api.rest import APIError

def fetch_multiple_symbols(api, symbols, days=360):
    data = {}
    for symbol in symbols:
        try:
            bars = api.get_bars(symbol, '1Day', limit=days).df  # Use '1Day' for daily data
            if not bars.empty:
                data[symbol] = bars
        except APIError as e:
            print(f"Error fetching data for {symbol}: {e}")
    return data