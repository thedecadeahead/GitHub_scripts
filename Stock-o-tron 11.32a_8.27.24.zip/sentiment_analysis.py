import requests
from textblob import TextBlob

def get_news_sentiment(symbol):
    url = f"https://newsapi.org/v2/everything?q={symbol}&apiKey=YOUR_NEWS_API_KEY"
    response = requests.get(url)
    articles = response.json().get('articles', [])
    
    sentiment_scores = []
    for article in articles:
        blob = TextBlob(article['description'])
        sentiment_scores.append(blob.sentiment.polarity)

    if sentiment_scores:
        return sum(sentiment_scores) / len(sentiment_scores)
    else:
        return 0  # Neutral if no news

def adjust_prediction_with_sentiment(symbol, prediction_probability):
    sentiment = get_news_sentiment(symbol)
    adjusted_prediction = prediction_probability + (sentiment * 0.1)  # Adjust based on sentiment
    return min(max(adjusted_prediction, 0), 1)  # Ensure between 0 and 1