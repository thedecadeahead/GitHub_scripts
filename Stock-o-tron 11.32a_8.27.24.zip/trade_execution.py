def execute_trade(api, symbol, model, data, risk_percentage=0.02):
    # Calculate the number of shares to buy
    cash = float(api.get_account().cash)
    risk_amount = cash * risk_percentage
    stop_loss = 0.98  # 2% stop loss
    take_profit = 1.05  # 5% take profit

    last_price = data[symbol]['close'].iloc[-1]
    quantity = int(risk_amount / (last_price * (1 - stop_loss)))

    if quantity > 0:
        # Predict probability of price increase
        X = data[symbol][['ma5', 'ma20', 'rsi', 'bollinger_band']].values[-1].reshape(1, -1)
        probability = model.predict_proba(X)[0][1]
        
        if probability > 0.7:  # Only trade if probability of success is high
            # Place limit buy order
            api.submit_order(
                symbol=symbol,
                qty=quantity,
                side='buy',
                type='limit',
                time_in_force='day',
                limit_price=last_price
            )
            # Set stop-loss and take-profit
            api.submit_order(
                symbol=symbol,
                qty=quantity,
                side='sell',
                type='stop_limit',
                stop_price=last_price * stop_loss,
                limit_price=last_price * stop_loss,
                time_in_force='gtc'
            )
            api.submit_order(
                symbol=symbol,
                qty=quantity,
                side='sell',
                type='limit',
                limit_price=last_price * take_profit,
                time_in_force='gtc'
            )
            print(f"Placed order for {symbol}: {quantity} shares at {last_price}")