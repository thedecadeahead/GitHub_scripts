
import joblib

def load_model(path):
    return joblib.load(path)
