
import requests
import json
import logging
from config import ALPACA_API_KEY, ALPACA_API_SECRET

# Script Title: stock-o-tron API Test Script

# Set up logging for debug
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# Define API URL and parameters
api_url = "https://paper-api.alpaca.markets/v2"
headers = {
    "APCA-API-KEY-ID": ALPACA_API_KEY,
    "APCA-API-SECRET-KEY": ALPACA_API_SECRET
}

def test_api():
    """
    Test the Alpaca API to retrieve account information and provide proper data formatting instructions.
    """
    # Making the API request to get account information
    response = requests.get(f"{api_url}/account", headers=headers)

    if response.status_code == 200:
        # Successful response
        logging.debug("API request successful.")
        account_info = response.json()
        print("Account Information:")
        print(json.dumps(account_info, indent=2))
    else:
        # API request failed
        logging.error(f"API request failed with status code {response.status_code}.")
        print(f"Error: Unable to retrieve account information. Status code: {response.status_code}")
        return

    # Instructions for proper data formatting (relevant for different API requests)
    print("\nData Formatting Instructions:")
    print("1. Ensure your data is in JSON format.")
    print("2. Required fields for placing orders: 'symbol', 'qty', 'side' (e.g., 'buy' or 'sell'), 'type' (e.g., 'market' or 'limit'), and 'time_in_force' (e.g., 'gtc').")
    print("3. Optional fields: 'limit_price', 'stop_price', 'client_order_id'.")

    # Example of proper data request format for placing an order
    example_data_request = {
        "symbol": "AAPL",
        "qty": 1,
        "side": "buy",
        "type": "market",
        "time_in_force": "gtc"
    }
    print("\nExample Data Request:")
    print(json.dumps(example_data_request, indent=2))

if __name__ == "__main__":
    test_api()
