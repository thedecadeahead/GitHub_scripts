
import os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from save_model import save_model

def train_models(data):
    models_dir = os.path.join(os.path.dirname(__file__), 'models')

    # Create the 'models' directory if it doesn't exist
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)

    models = {}
    for symbol, df in data.items():
        df = feature_engineering(df)
        
        if 'ma5' not in df.columns or 'ma20' not in df.columns or 'rsi' not in df.columns or 'returns' not in df.columns:
            print(f"Skipping {symbol} due to insufficient data for feature engineering.")
            continue
        
        X = df[['ma5', 'ma20', 'rsi', 'returns']].values
        y = np.where(df['close'].shift(-1) > df['close'], 1, 0)
        
        if len(X) == 0 or len(y) == 0:
            print(f"No training data available for {symbol}")
            continue
        
        print(f"Training model for {symbol} with {len(X)} samples")
        model = RandomForestClassifier(n_estimators=100)
        model.fit(X, y)
        
        # Save the model to the 'models' directory
        model_path = os.path.join(models_dir, f"{symbol}_model.pkl")
        save_model(model, model_path)
        
        models[symbol] = model
    
    return models
