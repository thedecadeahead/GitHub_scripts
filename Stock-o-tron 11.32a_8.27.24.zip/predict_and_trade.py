
def predict_and_trade(api, models, data):
    predictions = {}
    for symbol, model in models.items():
        df = data[symbol]
        if len(df) < 1:
            print(f"Not enough data to make predictions for {symbol}.")
            continue
        
        X = df[['ma5', 'ma20', 'rsi', 'returns']].values[-1].reshape(1, -1)
        predictions[symbol] = model.predict_proba(X)[0][1]  # Probability of price increase
    
    if not predictions:
        print("No valid predictions were made.")
        return
    
    best_stock = max(predictions, key=predictions.get)
    print(f"Best stock to trade: {best_stock} with a probability of {predictions[best_stock]}")
    # Execute the trade (dummy code)
    # api.submit_order(symbol=best_stock, qty=1, side='buy', type='market', time_in_force='gtc')
