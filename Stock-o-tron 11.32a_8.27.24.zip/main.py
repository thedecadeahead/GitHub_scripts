
import requests
import json
import logging
from config import ALPACA_API_KEY, ALPACA_API_SECRET

# Script Title: stock-o-tron Main Script

# Set up logging for debug
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# Define API URL and parameters
api_url = "https://paper-api.alpaca.markets/v2"
headers = {
    "APCA-API-KEY-ID": ALPACA_API_KEY,
    "APCA-API-SECRET-KEY": ALPACA_API_SECRET
}

def main():
    """
    Main function to interact with Alpaca API.
    """
    # Making the API request to get account information
    response = requests.get(f"{api_url}/account", headers=headers)

    if response.status_code == 200:
        # Successful response
        logging.debug("API request successful.")
        account_info = response.json()
        print("Account Information:")
        print(json.dumps(account_info, indent=2))
    else:
        # API request failed
        logging.error(f"API request failed with status code {response.status_code}.")
        print(f"Error: Unable to retrieve account information. Status code: {response.status_code}")
        return

    # Further actions can be added here

if __name__ == "__main__":
    main()
