import pandas as pd

def feature_engineering(df):
    df['ma5'] = df['close'].rolling(window=5).mean()
    df['ma20'] = df['close'].rolling(window=20).mean()
    df['rsi'] = compute_rsi(df['close'])
    df['bollinger_band'] = compute_bollinger_bands(df['close'])
    df.dropna(inplace=True)
    return df

def compute_rsi(series, period=14):
    delta = series.diff(1)
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_bollinger_bands(series, window=20):
    ma = series.rolling(window).mean()
    std = series.rolling(window).std()
    upper_band = ma + (std * 2)
    lower_band = ma - (std * 2)
    return (series - lower_band) / (upper_band - lower_band)