from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier

def cross_validate_model(X, y, cv=5):
    model = RandomForestClassifier(n_estimators=100)
    scores = cross_val_score(model, X, y, cv=cv)
    print(f"Cross-validation scores: {scores}")
    print(f"Average score: {scores.mean():.2f}")
    return model.fit(X, y)