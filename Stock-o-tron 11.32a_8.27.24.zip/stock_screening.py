def screen_stocks(api, min_price=0.5, max_price=5.0, min_volume=500000):
    screened_symbols = []
    assets = api.list_assets(status='active')

    for asset in assets:
        if asset.tradable:
            bars = api.get_bars(asset.symbol, '1Day', limit=10).df  # Fetch last 10 days of data
            if not bars.empty:
                last_close = bars['close'].iloc[-1]
                avg_volume = bars['volume'].mean()
                if min_price <= last_close <= max_price and avg_volume >= min_volume:
                    screened_symbols.append(asset.symbol)
    
    return screened_symbols